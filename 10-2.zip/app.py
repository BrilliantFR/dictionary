from flask import Flask, request, render_template, redirect, url_for, jsonify
from pymongo import MongoClient
import requests

app = Flask(__name__)

password = 'sparta'
cxn_str = f'mongodb+srv://Brilliant:{password}@cluster0.avtskzb.mongodb.net/?retryWrites=true&w=majority'
client = MongoClient(cxn_str)
db = client.dbsparta_02

@app.route('/')
def main():
    return render_template('index.html')

@app.route('/detail/<keyword>')
def detail(keyword):
    # keyword = request.args.get('keyword')
    print(keyword)
    return render_template('detail.html', word=keyword)

@app.route('/api/save_word', methods=['POST'])
def save_word():
    return jsonify({
        'result': 'success',
        'msg': 'the word was saved',
    })

@app.route('/api/delete_word', methods=['POST'])
def delete_word():
    return jsonify({
        'result': 'success',
        'msg': 'the word was deleted',
    })



# @app.route('/practice')
# def practice():
#     return render_template('practice.html')

if __name__ == '__main__':
    app.run('0.0.0.0', port=5000,debug=True)